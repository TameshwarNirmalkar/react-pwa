export const FETCH_EMP_DATA = "FETCH_EMP_DATA";
export const SET_ABT_TITLE = "SET_ABT_TITLE";
